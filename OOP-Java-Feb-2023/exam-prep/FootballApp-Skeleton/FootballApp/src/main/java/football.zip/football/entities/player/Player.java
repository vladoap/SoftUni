package football.entities.player;

public interface Player {
    void setName(String name);

    void stimulation();

    double getKg();

    String getName();

    int getStrength();


}
