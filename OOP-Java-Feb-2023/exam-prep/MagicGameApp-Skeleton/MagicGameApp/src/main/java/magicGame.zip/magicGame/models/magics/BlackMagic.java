package magicGame.models.magics;

public class BlackMagic extends MagicImpl {

    private static final int FIRED_BULLETS_AT_ONCE = 10;

    public BlackMagic(String name, int bulletsCount) {
        super(name, bulletsCount);
    }

    @Override
    public int fire() {

        if (getBulletsCount() - FIRED_BULLETS_AT_ONCE >= 0) {
            setBulletsCount(getBulletsCount() - FIRED_BULLETS_AT_ONCE);
            return FIRED_BULLETS_AT_ONCE;
        } else {
            return 0;
        }
    }
}
